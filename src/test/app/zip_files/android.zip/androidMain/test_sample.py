print('hello!?')
print('food')
